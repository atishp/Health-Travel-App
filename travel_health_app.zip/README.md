# travel
This HTML5 website template is part of a series of templates I am open sourcing. Website is completely responsive and is capable of sending mails (I have included a simple PHP mailer script). This is available for anyone to use both commercially or non-commercially. Credits would be much appreciated.  For live demo : http://www.yomeshgupta.com/demos/travel/index.html
